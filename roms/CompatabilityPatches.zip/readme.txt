Instructions:
Simply patch the IPS File to the Pokemon game with the same name (E.g. Patch Gold.ips to Pokemon Gold.gbc).  When you're done, you'll be able to trade between that and Brown!